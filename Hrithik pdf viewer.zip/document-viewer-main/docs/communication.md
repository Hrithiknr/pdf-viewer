# Main and worker thread communication

![between main and worker thread](./assets/communication.svg)
