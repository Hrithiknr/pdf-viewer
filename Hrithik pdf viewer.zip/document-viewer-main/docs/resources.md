# PDF Specifications

- [PDF 2.0](https://www.pdfa.org/sponsored-standards/)

# Blogs

- [Appligent - Learning PDF](https://labs.appligent.com/pdfblog/category/learning-pdf/)
