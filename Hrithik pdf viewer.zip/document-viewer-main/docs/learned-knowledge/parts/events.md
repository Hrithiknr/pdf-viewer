#### `documentinit`
