The global `PDFViewerApplication` object is the entry of the default viewer of PDF.js, it glues all the modules
together, and provides the API for the user.
