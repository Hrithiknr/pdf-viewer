<script setup></script>

<template>
  <div>View Content</div>
</template>
