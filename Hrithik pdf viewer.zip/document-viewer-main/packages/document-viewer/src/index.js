import { createViewerApp, getViewerConfiguration } from "./app_manager";

export { createViewerApp, getViewerConfiguration };
