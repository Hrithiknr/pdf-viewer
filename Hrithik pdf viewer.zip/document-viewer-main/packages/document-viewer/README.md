# PDF Viewer

An out-of-the-box PDF viewer based on PDF.js.

# Getting Started

```bash
npm create @document-kits/viewer@latest my-app

cd my-app

npm install
npm run dev
```
