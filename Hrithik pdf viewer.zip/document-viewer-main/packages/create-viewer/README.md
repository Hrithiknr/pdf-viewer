The starter for [@document-kits/viewer](https://www.npmjs.com/package/@document-kits/viewer)

```bash
? Which template do you want to use? › - Use arrow-keys. Return to submit.
>   vite-lit-template
    vite-solid-template
    vite-vue-template
```
