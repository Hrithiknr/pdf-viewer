module.exports = {
  printWidth: 99,
};
